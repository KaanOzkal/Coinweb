import { useState } from 'react'
import Index from './components/Index.jsx'

function App() {
  const [, ] = useState(0)

  return (
    <>
    <Index/>
    </>
  )
}

export default App
