import React, { useState, useEffect, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Modal.css';

const Index = () => {
    const [coinData, setCoinData] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [limit, setLimit] = useState(10);
    const [selectedCoin, setSelectedCoin] = useState(null);
    const videoRef = useRef(null);
    const aboutRef = useRef(null);
    const contactRef = useRef(null);
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    useEffect(() => {
        fetchCoinData(limit);

        const intervalId = setInterval(() => {
            fetchCoinData(limit);
        }, 15000);

        return () => clearInterval(intervalId);
    }, [limit]);

    const fetchCoinData = (limit) => {
        fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=${limit}&page=1&sparkline=false`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Ağ yanıtı olumlu değildi: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                const coins = data.map(coin => {
                    const previousCoin = coinData.find(c => c.id === coin.id);
                    const previousPrice = previousCoin ? previousCoin.price : coin.current_price;
                    const percentageChange = ((coin.current_price - previousPrice) / previousPrice) * 100;

                    return {
                        id: coin.id,
                        name: coin.name,
                        symbol: coin.symbol,
                        price: coin.current_price,
                        previousPrice,
                        percentageChange
                    };
                });
                setCoinData(coins);
            })
            .catch(error => console.error('Coin verileri alınırken hata oluştu:', error));
    };

    const handleSearch = (e) => {
        setSearchQuery(e.target.value.toLowerCase());
    };

    const handleLoadMore = () => {
        setLimit(prevLimit => prevLimit + 10);
    };

    const handleCoinClick = (coin) => {
        setSelectedCoin(coin);
    };

    const scrollToRef = (ref) => {
        ref.current.scrollIntoView({ behavior: 'smooth' });
    };

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    const closeMenu = () => {
        setIsMenuOpen(false);
    };

    const filteredCoins = searchQuery === '' ? coinData : coinData.filter(coin =>
        coin.name.toLowerCase().includes(searchQuery) || coin.symbol.toLowerCase().includes(searchQuery)
    );

    return (
        <>
            <link rel="preconnect" href="https://fonts.googleapis.com" />
            <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
            <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet" />

            <nav className="navbar navbar-expand-lg bg-dark">
                <div className="container-fluid">
                    <img className='icon' src="icon.jpg" alt="icon" />
                    <button className="navbar-toggler" type="button" onClick={toggleMenu}>
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className={`collapse navbar-collapse ${isMenuOpen ? 'show' : ''}`} id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link active text-light" aria-current="page" href="#" onClick={() => { scrollToRef(aboutRef); closeMenu(); }}>Ana Sayfa</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-light" href="#" onClick={() => { scrollToRef(contactRef); closeMenu(); }}>İletişim</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link text-light" href="#" onClick={() => { scrollToRef(contactRef); closeMenu(); }}>Hakkımda</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <form className="d-flex mt-3 mb-3" role="search">
                <input className="form-control me-2 bg-dark text-light" type="search" placeholder="Coin arayın" aria-label="Search" onChange={handleSearch} />
                <button className="btn btn-outline-light" type="button">Ara</button>
            </form>
            <div>
                <h1 className='header text-light' style={{ fontFamily: 'Lobster, cursive' }}>Holm Coin</h1>
            </div>

            {filteredCoins.length > 0 ? (
                <div className="table-responsive">
                    <table className="table table-striped table-dark">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">İsim</th>
                                <th scope="col">Sembol</th>
                                <th scope="col">Birim</th>
                                <th scope="col">Yüzde Değişim</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredCoins.map((coin, index) => (
                                <tr key={coin.id} onClick={() => handleCoinClick(coin)}>
                                    <th scope="row">{index + 1}</th>
                                    <td>{coin.name}</td>
                                    <td>{coin.symbol.toUpperCase()}</td>
                                    <td>${coin.price.toFixed(2)}</td>
                                    <td style={{ color: coin.percentageChange >= 0 ? 'green' : 'red' }}>
                                        {coin.percentageChange.toFixed(2)}%
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <button className="btn btn-primary container" onClick={handleLoadMore}>Daha Fazla coin ve hızlı veri güncellemesi için basınız</button>
                </div>
            ) : (
                <div className="text-center mt-3">
                    <span className="spinner-border text-light" role="status" aria-hidden="true"></span>
                    <p className="text-light">Veri Bekleniyor</p>
                </div>
            )}
<br />
<br />
            <div class="container">
                <div ref={aboutRef} data-aos="fade-up">
                    <h1 className='text-primary'>Hakkımda</h1>
                    <p className="text-light">Kimiz Biz?
                        HolmCoin, kripto para dünyasında yenilikçi çözümler sunmak ve kripto ekosistemini herkes için daha erişilebilir hale getirmek amacıyla kuruldu. Ekibimiz, blockchain teknolojisi ve kripto para birimlerinde uzmanlaşmış profesyonellerden oluşmaktadır.</p>
                </div>
                <br />

                <div ref={contactRef} data-aos="fade-up" data-aos-delay="100">
                    <h1 className='text-primary'>Vizyonumuz</h1>
                    <p className="text-light">Kripto para dünyasında lider bilgi kaynağı olmak ve teknolojinin sunduğu yenilikleri en doğru şekilde aktararak, herkesin bu fırsatlardan yararlanabilmesini sağlamak. Yenilikçi yaklaşımlarımız ve kapsamlı araştırmalarımızla kripto para ekosistemine katkıda bulunmayı hedefliyoruz.</p>
                </div>
                <br />
                <div data-aos="fade-up" data-aos-delay="200">
                    <h1 className='text-primary'>Değerlerimiz</h1>
                    <p className='text-light'>Güven: Bilgi ve hizmetlerimizde güvenilirlik en üst sıradadır. Kullanıcılarımızın güvenliğini ve gizliliğini ön planda tutarız.
                        Şeffaflık: Tüm faaliyetlerimizde açık ve dürüst bir iletişim benimseriz. Bilgiyi en doğru şekilde sunmak için çalışırız.
                        Yenilikçilik: Sürekli değişen kripto dünyasında en son trendleri ve teknolojik gelişmeleri takip eder, kullanıcılarımıza sunarız.
                        Eğitim: Kullanıcılarımızın kripto paralar hakkında bilinçlenmelerine yardımcı olmak için eğitim materyalleri ve rehberler sunarız.</p>
                </div>
                <br />
                <div data-aos="fade-up" data-aos-delay="300">
                    <h1 className='text-primary'>Hizmetlerimiz</h1>
                    <p className='text-light'>Piyasa Analizleri: Güncel kripto para piyasası analizleri ve raporları.
                        Eğitim İçerikleri: Kripto dünyasına yeni başlayanlar için kapsamlı rehberler ve eğitim videoları.
                        Yatırım Stratejileri: Bilinçli yatırım kararları almanızı sağlayacak stratejiler ve tavsiyeler.
                        Güvenlik: Dijital varlıklarınızın güvenliğini sağlamak için en iyi uygulamalar ve çözümler.
                        Kripto dünyasında güvenilir bir yol arkadaşı arıyorsanız, HolmCoin sizin için burada. Bizimle iletişime geçmek ve daha fazla bilgi almak için t.me/dholm adresini ziyaret edebilirsiniz.</p>
                </div>
            </div>
        </>
    );
};

export default Index;
